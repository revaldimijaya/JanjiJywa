<div>
    <img src="{{asset('/storage/logo/logo.png')}}">
</div>
