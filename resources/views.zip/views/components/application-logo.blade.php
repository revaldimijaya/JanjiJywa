<div>
    <img src="/public/storage/logo/logo.png">
</div>
